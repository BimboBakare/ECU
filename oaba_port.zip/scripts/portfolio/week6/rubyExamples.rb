<<<<<<< HEAD
#!/usr/bin/ruby

# rubyExamples.rb - Ruby rubyExamples# Author 'Bimbo  Bakare
# Date 19Feb2022


puts "Hello" #or you can also say

puts("Hi there!")

value= "blah"

items = [1,2,5,31,32,5,7]

puts("The value is" + value)

for item in items
    puts(item)
end


=======
#!/usr/bin/ruby

# rubyExamples.rb - Ruby rubyExamples# Author 'Bimbo  Bakare
# Date 19Feb2022


puts "Hello" #or you can also say

puts("Hi there!")

value= "blah"

items = [1,2,5,31,32,5,7]

puts("The value is" + value)

for item in items
    puts(item)
end


>>>>>>> e5fa5d5b524d233f2c5acaaff70733c9214ee2aa
