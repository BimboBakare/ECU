<<<<<<< HEAD
#!/Users/bin/ruby
# notice the shebang is different
# pythonExamples - showing the differences in python
# Author: Bimbo Bakare
# Date 19Feb2022

print("Hi there !")

value = "blah"
y = 20

print("The value is - - %s" % value)
if (y < 10):
    print("y is very small")
else:
    print("y is very big")

    print("Some other statements added")


# notice no end or fi to the if else statement. python uses whitespaces
# Indentation will stermine what will be xecuted or not as part of the if or any command syntax, so indentation is big
# python uses : instead of ; as in bash
=======
#!/Users/bin/ruby
# notice the shebang is different
# pythonExamples - showing the differences in python
# Author: Bimbo Bakare
# Date 19Feb2022

print("Hi there !")

value = "blah"
y = 20

print("The value is - - %s" % value)
if (y < 10):
    print("y is very small")
else:
    print("y is very big")

    print("Some other statements added")


# notice no end or fi to the if else statement. python uses whitespaces
# Indentation will stermine what will be xecuted or not as part of the if or any command syntax, so indentation is big
# python uses : instead of ; as in bash
>>>>>>> e5fa5d5b524d233f2c5acaaff70733c9214ee2aa
