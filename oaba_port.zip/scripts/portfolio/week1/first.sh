#!/bin/bash
echo "hi there"
echo "My name is Olu"
exit 22
