#!/bin/bash
echo -n "Printing text with new line"
echo  -n "Printing text without newline"
echo   "-n -     makes sense?"
echo -e "\nRemoving \t backslash \t characters\n"
exit 0


