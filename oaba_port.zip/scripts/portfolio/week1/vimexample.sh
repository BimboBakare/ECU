#!/bin/bash
echo "hello from vim"
exit 0

