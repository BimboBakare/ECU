#!/bin/bash
echo "hello from nano"
exit 0

