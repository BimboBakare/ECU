#!/bin/bash
echo "hello from emacs!"
exit 0
